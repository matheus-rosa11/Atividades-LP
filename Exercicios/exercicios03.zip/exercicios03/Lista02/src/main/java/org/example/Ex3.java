package org.example;

public class Ex3 {
    public static void main(String[] args) {


        int i = 0;


        while (i <= 40) {

            System.out.println(i);

            i += 2;

        }

    }
}
