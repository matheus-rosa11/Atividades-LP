package org.example;

public class Ex3 {
    [16:22] Diego Sorrens
    public static void main(String[] args) {

        int i = 0;
       
        while (i <= 40) {
            System.out.println(i);
            i +=2;
        }
    }


}
