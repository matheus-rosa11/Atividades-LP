package org.example;

public class Main {
    public static void main(String[] args) {
        for (Integer i = 0; i <= 90; i++) {

            if (i % 2 == 1) {

                System.out.println(i);

            }

        }


    }


}
