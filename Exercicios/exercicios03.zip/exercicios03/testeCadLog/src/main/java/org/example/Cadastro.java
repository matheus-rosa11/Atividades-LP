package org.example;

public class Cadastro {

}
