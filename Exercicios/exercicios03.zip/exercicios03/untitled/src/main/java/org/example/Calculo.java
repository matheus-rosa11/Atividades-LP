package org.example;

public class Calculo {
    public Double calcularMedia(Double n1, Double n2){
        return ((n1 * 0.4) + (n2 * 0.6));
    }
}
